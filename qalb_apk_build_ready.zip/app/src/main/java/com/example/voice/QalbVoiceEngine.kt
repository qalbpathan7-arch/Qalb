package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

private const val TAG = "QalbVoiceEngine"

data class VoiceEngineState(
    val isListening: Boolean = false,
    val rmsDb: Float = 0f,
    val partialTranscript: String = "",
    val isSpeaking: Boolean = false,
    val speakingMessageId: Long? = null,
    val ttsReady: Boolean = false,
    val speechAvailable: Boolean = true,
    val voiceError: String? = null,
)

class QalbVoiceEngine(context: Context) {
    private val appContext = context.applicationContext

    private val _state = MutableStateFlow(
        VoiceEngineState(
            speechAvailable = SpeechRecognizer.isRecognitionAvailable(appContext),
        )
    )
    val state: StateFlow<VoiceEngineState> = _state.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var onFinalTranscriptCallback: ((String) -> Unit)? = null

    init {
        initTts()
    }

    private fun initTts() {
        try {
            textToSpeech = TextToSpeech(appContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val tts = textToSpeech
                    val indianEnglish = Locale("en", "IN")
                    val result = tts?.setLanguage(indianEnglish)
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts?.setLanguage(Locale.US)
                    }
                    // Prefer a deeper male voice if available on device
                    tts?.voices?.firstOrNull { voice ->
                        !voice.isNetworkConnectionRequired &&
                            (voice.name.contains("male", ignoreCase = true) ||
                                voice.name.contains("-in-x-", ignoreCase = true))
                    }?.let { preferred ->
                        tts.voice = preferred
                    }
                    tts?.setOnUtteranceProgressListener(
                        object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) {
                                _state.update { it.copy(isSpeaking = true) }
                            }

                            override fun onDone(utteranceId: String?) {
                                _state.update {
                                    it.copy(isSpeaking = false, speakingMessageId = null)
                                }
                            }

                            @Deprecated("Deprecated in Java")
                            override fun onError(utteranceId: String?) {
                                _state.update {
                                    it.copy(isSpeaking = false, speakingMessageId = null)
                                }
                            }

                            override fun onError(utteranceId: String?, errorCode: Int) {
                                _state.update {
                                    it.copy(isSpeaking = false, speakingMessageId = null)
                                }
                            }
                        }
                    )
                    _state.update { it.copy(ttsReady = true) }
                } else {
                    Log.w(TAG, "TextToSpeech init failed with status=$status")
                    _state.update { it.copy(ttsReady = false) }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Unable to initialize TTS", e)
            _state.update { it.copy(ttsReady = false) }
        }
    }

    fun startListening(onTranscriptReady: (String) -> Unit) {
        stopSpeaking()
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            _state.update {
                it.copy(
                    speechAvailable = false,
                    isListening = false,
                    voiceError = "On-device speech recognition service is unavailable on this device.",
                )
            }
            return
        }

        onFinalTranscriptCallback = onTranscriptReady
        _state.update {
            it.copy(
                isListening = true,
                partialTranscript = "",
                rmsDb = 0f,
                voiceError = null,
            )
        }

        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(appContext).apply {
                setRecognitionListener(
                    object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            _state.update { it.copy(isListening = true, voiceError = null) }
                        }

                        override fun onBeginningOfSpeech() = Unit

                        override fun onRmsChanged(rmsdB: Float) {
                            _state.update { it.copy(rmsDb = rmsdB.coerceIn(0f, 12f)) }
                        }

                        override fun onBufferReceived(buffer: ByteArray?) = Unit

                        override fun onEndOfSpeech() {
                            _state.update { it.copy(isListening = false, rmsDb = 0f) }
                        }

                        override fun onError(error: Int) {
                            val msg = when (error) {
                                SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that clearly. Try again."
                                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected. Tap the mic when ready."
                                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
                                SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
                                SpeechRecognizer.ERROR_NETWORK,
                                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech service requires network or offline language pack."
                                else -> "Voice input paused ($error). Please try again."
                            }
                            _state.update {
                                it.copy(
                                    isListening = false,
                                    rmsDb = 0f,
                                    voiceError = msg,
                                )
                            }
                        }

                        override fun onResults(results: Bundle?) {
                            val matches =
                                results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val finalText = matches?.firstOrNull()?.trim().orEmpty()
                            _state.update {
                                it.copy(
                                    isListening = false,
                                    rmsDb = 0f,
                                    partialTranscript = finalText,
                                )
                            }
                            if (finalText.isNotBlank()) {
                                onFinalTranscriptCallback?.invoke(finalText)
                            }
                        }

                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches =
                                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val partial = matches?.firstOrNull()?.trim().orEmpty()
                            if (partial.isNotBlank()) {
                                _state.update { it.copy(partialTranscript = partial) }
                            }
                        }

                        override fun onEvent(eventType: Int, params: Bundle?) = Unit
                    }
                )
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "SpeechRecognizer start failed", e)
            _state.update {
                it.copy(
                    isListening = false,
                    voiceError = e.localizedMessage ?: "Unable to start microphone.",
                )
            }
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            Log.w(TAG, "stopListening error", e)
        }
        _state.update { it.copy(isListening = false, rmsDb = 0f) }
    }

    fun speak(
        text: String,
        messageId: Long?,
        pitch: Float,
        speed: Float,
    ) {
        val cleanText = text.removePrefix("[Sample Preview]").trim()
        if (cleanText.isBlank()) return

        val tts = textToSpeech
        if (tts == null || !_state.value.ttsReady) {
            _state.update { it.copy(voiceError = "Spoken voice engine is initializing or unavailable.") }
            return
        }

        tts.setPitch(pitch.coerceIn(0.65f, 1.1f))
        tts.setSpeechRate(speed.coerceIn(0.75f, 1.25f))
        _state.update {
            it.copy(
                isSpeaking = true,
                speakingMessageId = messageId,
                voiceError = null,
            )
        }
        val utteranceId = "qalb_${messageId ?: System.currentTimeMillis()}"
        tts.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stopSpeaking() {
        try {
            textToSpeech?.stop()
        } catch (e: Exception) {
            Log.w(TAG, "stopSpeaking error", e)
        }
        _state.update { it.copy(isSpeaking = false, speakingMessageId = null) }
    }

    fun clearError() {
        _state.update { it.copy(voiceError = null) }
    }

    fun release() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
            textToSpeech?.stop()
            textToSpeech?.shutdown()
            textToSpeech = null
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing voice engine", e)
        }
    }
}
