package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class QalbExtendedColors(
    val goldBorder: Color,
    val goldGlow: Color,
    val userBubble: Color,
    val qalbBubble: Color,
    val onlinePresence: Color,
    val subtleText: Color,
)

val LocalQalbColors = staticCompositionLocalOf {
    QalbExtendedColors(
        goldBorder = SubtleGoldBorder,
        goldGlow = WarmGoldHighlight,
        userBubble = UserBubbleDark,
        qalbBubble = VelvetCard,
        onlinePresence = EmeraldPresence,
        subtleText = AshSubtle,
    )
}

private val QalbDarkColorScheme = darkColorScheme(
    primary = ChampagneGold,
    onPrimary = VoidBlack,
    primaryContainer = MutedGoldWash,
    onPrimaryContainer = WarmGoldHighlight,
    secondary = BurnishedGold,
    onSecondary = VoidBlack,
    secondaryContainer = ElevatedCharcoal,
    onSecondaryContainer = WarmIvory,
    tertiary = WarmGoldHighlight,
    onTertiary = VoidBlack,
    background = VoidBlack,
    onBackground = WarmIvory,
    surface = ObsidianSurface,
    onSurface = WarmIvory,
    surfaceVariant = VelvetCard,
    onSurfaceVariant = StoneMuted,
    surfaceContainerLowest = VoidBlack,
    surfaceContainerLow = ObsidianSurface,
    surfaceContainer = VelvetCard,
    surfaceContainerHigh = ElevatedCharcoal,
    outline = SubtleGoldBorder,
    outlineVariant = Color(0xFF23222A),
    error = SoftRoseGoldError,
    onError = VoidBlack,
    errorContainer = DeepRubyContainer,
    onErrorContainer = SoftRoseGoldError,
)

val QalbShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun QalbTheme(
    content: @Composable () -> Unit,
) {
    val extendedColors = QalbExtendedColors(
        goldBorder = SubtleGoldBorder,
        goldGlow = WarmGoldHighlight,
        userBubble = UserBubbleDark,
        qalbBubble = VelvetCard,
        onlinePresence = EmeraldPresence,
        subtleText = AshSubtle,
    )

    CompositionLocalProvider(LocalQalbColors provides extendedColors) {
        MaterialTheme(
            colorScheme = QalbDarkColorScheme,
            typography = QalbTypography,
            shapes = QalbShapes,
            content = content,
        )
    }
}
