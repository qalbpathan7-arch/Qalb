package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.QalbUiState
import com.example.ui.components.QalbAvatar
import com.example.ui.theme.LocalQalbColors
import com.example.ui.theme.MutedGoldWash
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PersonalityAvatarScreen(
    state: QalbUiState,
    onUploadReferenceImage: (android.net.Uri) -> Unit,
    onRestorePermanentAvatar: () -> Unit,
    onUpdateSliders: (warmth: Float, wit: Float, romance: Float, hinglish: Float) -> Unit,
    onUpdateCustomDirective: (String) -> Unit,
    onUpdateVoiceSettings: (pitch: Float, speed: Float, autoSpeak: Boolean) -> Unit,
    onTestVoice: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val qalbColors = LocalQalbColors.current
    val config = state.personality

    var warmth by remember(config.warmthLevel) { mutableFloatStateOf(config.warmthLevel) }
    var wit by remember(config.witLevel) { mutableFloatStateOf(config.witLevel) }
    var romance by remember(config.romanceSubtlety) { mutableFloatStateOf(config.romanceSubtlety) }
    var hinglish by remember(config.hinglishBlend) { mutableFloatStateOf(config.hinglishBlend) }
    var directiveDraft by remember(config.customDirective) { mutableStateOf(config.customDirective) }

    var voicePitch by remember(config.voicePitch) { mutableFloatStateOf(config.voicePitch) }
    var voiceSpeed by remember(config.voiceSpeed) { mutableFloatStateOf(config.voiceSpeed) }

    // Zero-permission Android Photo Picker per Google Play policy
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
    ) { uri ->
        if (uri != null) {
            onUploadReferenceImage(uri)
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        item {
            Column(
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxWidth(),
            ) {
                Text(
                    text = "QALB PERSONA",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    text = "Customize Qalb's permanent portrait, emotional cadence, and voice tone",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        // Reference Avatar Studio
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, qalbColors.goldBorder),
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    QalbAvatar(
                        customAvatarPath = config.customAvatarPath,
                        size = 128.dp,
                        isPulsing = state.voiceState.isSpeaking,
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = if (config.customAvatarPath != null) {
                            "Custom Reference Portrait Active"
                        } else {
                            "Permanent Qalb Portrait Active"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Upload any reference photo from your gallery to update Qalb's face across chat and voice mode.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary,
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("upload_avatar_button"),
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Upload Reference")
                        }

                        if (config.customAvatarPath != null) {
                            OutlinedButton(
                                onClick = onRestorePermanentAvatar,
                                border = BorderStroke(1.dp, qalbColors.goldBorder),
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("restore_avatar_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Restore permanent avatar",
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Permanent", color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }

        // Personality Matrix
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, qalbColors.goldBorder),
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Personality Calibration",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        PresetChip("Calm & Grounded") {
                            warmth = 0.85f; wit = 0.45f; romance = 0.40f; hinglish = 0.75f
                            onUpdateSliders(warmth, wit, romance, hinglish)
                        }
                        PresetChip("Playful & Witty") {
                            warmth = 0.72f; wit = 0.92f; romance = 0.55f; hinglish = 0.82f
                            onUpdateSliders(warmth, wit, romance, hinglish)
                        }
                        PresetChip("Warm & Romantic") {
                            warmth = 0.95f; wit = 0.65f; romance = 0.88f; hinglish = 0.85f
                            onUpdateSliders(warmth, wit, romance, hinglish)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    PersonalitySliderRow(
                        label = "Emotional Warmth",
                        value = warmth,
                        onValueChange = { warmth = it },
                        onValueChangeFinished = { onUpdateSliders(warmth, wit, romance, hinglish) },
                    )
                    PersonalitySliderRow(
                        label = "Playful Wit",
                        value = wit,
                        onValueChange = { wit = it },
                        onValueChangeFinished = { onUpdateSliders(warmth, wit, romance, hinglish) },
                    )
                    PersonalitySliderRow(
                        label = "Subtle Romance",
                        value = romance,
                        onValueChange = { romance = it },
                        onValueChangeFinished = { onUpdateSliders(warmth, wit, romance, hinglish) },
                    )
                    PersonalitySliderRow(
                        label = "Natural Hinglish Blend",
                        value = hinglish,
                        onValueChange = { hinglish = it },
                        onValueChangeFinished = { onUpdateSliders(warmth, wit, romance, hinglish) },
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = directiveDraft,
                        onValueChange = { directiveDraft = it },
                        label = { Text("Custom Personality Note") },
                        placeholder = {
                            Text("e.g., Keep replies thoughtful, concise, and grounded")
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = qalbColors.goldBorder,
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("custom_directive_input"),
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { onUpdateCustomDirective(directiveDraft) },
                        modifier = Modifier
                            .align(Alignment.End)
                            .height(48.dp)
                            .testTag("save_directive_button"),
                    ) {
                        Text("Apply Note")
                    }
                }
            }
        }

        // Voice Calibration
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, qalbColors.goldBorder),
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Voice & Spoken Replies",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Auto-Speak Text Replies",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                            Text(
                                text = "Read Qalb's responses aloud automatically in chat",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Switch(
                            checked = config.autoSpeakReplies,
                            onCheckedChange = { autoSpeak ->
                                onUpdateVoiceSettings(voicePitch, voiceSpeed, autoSpeak)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                                checkedTrackColor = MaterialTheme.colorScheme.primary,
                            ),
                            modifier = Modifier.testTag("auto_speak_switch"),
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Voice Depth (Pitch): ${(voicePitch * 100).roundToInt()}%",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Slider(
                        value = voicePitch,
                        onValueChange = { voicePitch = it },
                        valueRange = 0.65f..1.10f,
                        onValueChangeFinished = {
                            onUpdateVoiceSettings(voicePitch, voiceSpeed, config.autoSpeakReplies)
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                        ),
                    )

                    Text(
                        text = "Speech Cadence (Rate): ${(voiceSpeed * 100).roundToInt()}%",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Slider(
                        value = voiceSpeed,
                        onValueChange = { voiceSpeed = it },
                        valueRange = 0.75f..1.25f,
                        onValueChangeFinished = {
                            onUpdateVoiceSettings(voicePitch, voiceSpeed, config.autoSpeakReplies)
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                        ),
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = onTestVoice,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("test_voice_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Preview Qalb's Spoken Voice",
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PresetChip(
    label: String,
    onClick: () -> Unit,
) {
    val qalbColors = LocalQalbColors.current
    AssistChip(
        onClick = onClick,
        label = { Text(label) },
        colors = AssistChipDefaults.assistChipColors(
            containerColor = MutedGoldWash,
            labelColor = MaterialTheme.colorScheme.primary,
        ),
        border = BorderStroke(1.dp, qalbColors.goldBorder),
    )
}

@Composable
private fun PersonalitySliderRow(
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
                text = "${(value * 100).roundToInt()}%",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            onValueChangeFinished = onValueChangeFinished,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
            ),
        )
    }
}
