package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.ChatMessageEntity
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.LocalQalbColors
import com.example.ui.theme.MutedGoldWash
import com.example.ui.theme.VoidBlack
import com.example.voice.VoiceEngineState

@Composable
fun VoiceStudioSheet(
    customAvatarPath: String?,
    voiceState: VoiceEngineState,
    isComposingReply: Boolean,
    latestQalbMessage: ChatMessageEntity?,
    isLiveGeminiEnabled: Boolean,
    onStartListening: () -> Unit,
    onStopListening: () -> Unit,
    onStopSpeaking: () -> Unit,
    onDismiss: () -> Unit,
) {
    val qalbColors = LocalQalbColors.current
    val pulseScale by animateFloatAsState(
        targetValue = when {
            voiceState.isListening -> 1f + (voiceState.rmsDb / 12f) * 0.22f
            voiceState.isSpeaking -> 1.12f
            else -> 1f
        },
        animationSpec = spring(),
        label = "voice_rms_pulse",
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        MutedGoldWash.copy(alpha = 0.85f),
                        VoidBlack,
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 16.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 560.dp)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column {
                    Text(
                        text = "QALB VOICE",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        text = when {
                            voiceState.isListening -> "Listening quietly…"
                            isComposingReply -> "Thinking…"
                            voiceState.isSpeaking -> "Speaking to you…"
                            else -> "Tap the mic to speak"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("close_voice_studio_button"),
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close voice conversation",
                        tint = MaterialTheme.colorScheme.onBackground,
                    )
                }
            }

            if (!isLiveGeminiEnabled) {
                Spacer(modifier = Modifier.height(12.dp))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, qalbColors.goldBorder),
                ) {
                    Text(
                        text = stringResource(R.string.ai_preview_notice),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Box(contentAlignment = Alignment.Center) {
                Box(
                    modifier = Modifier
                        .size(210.dp)
                        .clip(CircleShape)
                        .border(
                            width = 1.dp,
                            color = ChampagneGold.copy(alpha = if (voiceState.isListening || voiceState.isSpeaking) 0.35f else 0.12f),
                            shape = CircleShape,
                        )
                )
                QalbAvatar(
                    customAvatarPath = customAvatarPath,
                    size = 160.dp,
                    isPulsing = voiceState.isSpeaking || isComposingReply,
                    externalPulseScale = pulseScale,
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            val displayQuote = when {
                voiceState.isListening && voiceState.partialTranscript.isNotBlank() ->
                    "“${voiceState.partialTranscript}”"
                voiceState.voiceError != null -> voiceState.voiceError
                latestQalbMessage != null ->
                    latestQalbMessage.content.removePrefix("[Sample Preview]").trim()
                else -> "Kaho, aaj kis baat par baat karni hai?"
            }

            Text(
                text = displayQuote,
                style = MaterialTheme.typography.headlineSmall,
                color = if (voiceState.voiceError != null) {
                    MaterialTheme.colorScheme.error
                } else {
                    MaterialTheme.colorScheme.onBackground
                },
                textAlign = TextAlign.Center,
                maxLines = 5,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 12.dp),
            )

            Spacer(modifier = Modifier.weight(1f))

            Row(
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (voiceState.isSpeaking) {
                    FilledIconButton(
                        onClick = onStopSpeaking,
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.primary,
                        ),
                        modifier = Modifier
                            .size(56.dp)
                            .testTag("voice_stop_speaking_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = stringResource(R.string.cd_stop_voice),
                        )
                    }
                }

                FilledIconButton(
                    onClick = {
                        if (voiceState.isListening) onStopListening() else onStartListening()
                    },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (voiceState.isListening) {
                            MaterialTheme.colorScheme.tertiary
                        } else {
                            MaterialTheme.colorScheme.primary
                        },
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                    ),
                    modifier = Modifier
                        .size(76.dp)
                        .testTag("voice_studio_mic_orb"),
                ) {
                    Icon(
                        imageVector = if (voiceState.isListening) {
                            Icons.Default.GraphicEq
                        } else {
                            Icons.Default.Mic
                        },
                        contentDescription = stringResource(R.string.cd_microphone),
                        modifier = Modifier.size(32.dp),
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = if (voiceState.isListening) "Listening… tap to finish" else "Tap to speak in Hinglish or English",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
