package com.example.ui

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiRepository
import com.example.data.ai.PlaceholderQalbAiRepository
import com.example.data.local.ChatMessageEntity
import com.example.data.local.ConversationEntity
import com.example.data.local.MemoryFactEntity
import com.example.data.local.PersonalityConfig
import com.example.data.local.QalbDao
import com.example.data.local.QalbDatabase
import com.example.data.local.QalbPreferencesRepository
import com.example.voice.QalbVoiceEngine
import com.example.voice.VoiceEngineState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class QalbUiState(
    val activeConversationId: Long = -1L,
    val conversations: List<ConversationEntity> = emptyList(),
    val messages: List<ChatMessageEntity> = emptyList(),
    val memories: List<MemoryFactEntity> = emptyList(),
    val personality: PersonalityConfig = PersonalityConfig(),
    val voiceState: VoiceEngineState = VoiceEngineState(),
    val isComposingReply: Boolean = false,
    val isVoiceStudioOpen: Boolean = false,
    val isVaultLocked: Boolean = false,
    val pinError: String? = null,
    val composerDraft: String = "",
    val statusNotice: String? = null,
    val isLiveGeminiEnabled: Boolean = false,
)

@OptIn(ExperimentalCoroutinesApi::class)
class QalbViewModel(
    private val dao: QalbDao,
    private val prefs: QalbPreferencesRepository,
    private val aiRepository: AiRepository,
    private val voiceEngine: QalbVoiceEngine,
) : ViewModel() {

    private val isComposingReply = MutableStateFlow(false)
    private val isVoiceStudioOpen = MutableStateFlow(false)
    private val isVaultLocked = MutableStateFlow(false)
    private val pinError = MutableStateFlow<String?>(null)
    private val composerDraft = MutableStateFlow("")
    private val statusNotice = MutableStateFlow<String?>(null)
    private var initialPinChecked = false

    private val conversationsFlow = dao.observeConversations()
    private val memoriesFlow = dao.observeMemories()
    private val configFlow = prefs.configFlow

    private val activeMessagesFlow = combine(configFlow, conversationsFlow) { config, conversations ->
        when {
            config.activeConversationId > 0L && conversations.any { it.id == config.activeConversationId } ->
                config.activeConversationId
            conversations.isNotEmpty() -> conversations.first().id
            else -> -1L
        }
    }.flatMapLatest { convoId ->
        if (convoId > 0L) dao.observeMessages(convoId) else flowOf(emptyList())
    }

    private data class CoreSnapshot(
        val conversations: List<ConversationEntity>,
        val messages: List<ChatMessageEntity>,
        val memories: List<MemoryFactEntity>,
        val config: PersonalityConfig,
        val voiceState: VoiceEngineState,
    )

    private val coreFlow = combine(
        conversationsFlow,
        activeMessagesFlow,
        memoriesFlow,
        configFlow,
        voiceEngine.state,
    ) { conversations, messages, memories, config, voice ->
        CoreSnapshot(conversations, messages, memories, config, voice)
    }

    private data class EphemeralSnapshot(
        val composing: Boolean,
        val voiceOpen: Boolean,
        val locked: Boolean,
        val pinErr: String?,
        val draft: String,
        val notice: String?,
    )

    private val ephemeralFlow = combine(
        isComposingReply,
        isVoiceStudioOpen,
        isVaultLocked,
        pinError,
        composerDraft,
    ) { composing, voiceOpen, locked, pinErr, draft ->
        EphemeralSnapshot(composing, voiceOpen, locked, pinErr, draft, null)
    }.combine(statusNotice) { snap, notice ->
        snap.copy(notice = notice)
    }

    val uiState: StateFlow<QalbUiState> = combine(coreFlow, ephemeralFlow) { core, eph ->
        val resolvedId = when {
            core.config.activeConversationId > 0L &&
                core.conversations.any { it.id == core.config.activeConversationId } ->
                core.config.activeConversationId
            core.conversations.isNotEmpty() -> core.conversations.first().id
            else -> -1L
        }

        if (!initialPinChecked && core.config.pinHash.isNotBlank()) {
            initialPinChecked = true
            if (core.config.pinLockEnabled) {
                isVaultLocked.value = true
            }
        } else if (!initialPinChecked && !core.config.pinLockEnabled) {
            initialPinChecked = true
        }

        QalbUiState(
            activeConversationId = resolvedId,
            conversations = core.conversations,
            messages = core.messages,
            memories = core.memories,
            personality = core.config,
            voiceState = core.voiceState,
            isComposingReply = eph.composing,
            isVoiceStudioOpen = eph.voiceOpen,
            isVaultLocked = eph.locked,
            pinError = eph.pinErr,
            composerDraft = eph.draft,
            statusNotice = eph.notice,
            isLiveGeminiEnabled = aiRepository.isLiveGeminiEnabled,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = QalbUiState(isLiveGeminiEnabled = aiRepository.isLiveGeminiEnabled),
    )

    init {
        ensureInitialConversation()
    }

    private fun ensureInitialConversation() {
        viewModelScope.launch {
            val currentState = uiState.value
            if (currentState.conversations.isEmpty() && currentState.activeConversationId <= 0L) {
                // Seed only when user starts or leave empty for clean onboarding; keep DB clean.
            }
        }
    }

    fun updateComposerDraft(text: String) {
        composerDraft.value = text
    }

    fun sendMessage(
        rawText: String = composerDraft.value,
        isVoiceInput: Boolean = false,
        speakReplyOverride: Boolean = false,
    ) {
        val text = rawText.trim()
        if (text.isBlank() || isComposingReply.value) return

        if (!isVoiceInput) {
            composerDraft.value = ""
        }

        viewModelScope.launch {
            isComposingReply.value = true
            try {
                var convoId = uiState.value.activeConversationId
                if (convoId <= 0L) {
                    val title = text.take(36).let { if (text.length > 36) "$it…" else it }
                    convoId = dao.insertConversation(
                        ConversationEntity(
                            title = title,
                            lastMessagePreview = text,
                        )
                    )
                    prefs.setActiveConversationId(convoId)
                }

                val now = System.currentTimeMillis()
                dao.insertMessage(
                    ChatMessageEntity(
                        conversationId = convoId,
                        isFromUser = true,
                        content = text,
                        timestamp = now,
                        isVoiceInput = isVoiceInput,
                    )
                )

                val existingConvo = dao.getConversationById(convoId)
                val updatedTitle = if (existingConvo == null || existingConvo.title == "New Conversation") {
                    text.take(36).let { if (text.length > 36) "$it…" else it }
                } else {
                    existingConvo.title
                }
                dao.updateConversationSummary(
                    id = convoId,
                    title = updatedTitle,
                    updatedAt = now,
                    preview = text.take(80),
                )

                val config = uiState.value.personality
                if (config.longTermMemoryEnabled) {
                    aiRepository.extractMemoryCandidate(text)?.let { candidate ->
                        val existingMemories = dao.getMemoriesSnapshot()
                        val duplicate = existingMemories.any {
                            it.content.equals(candidate.content, ignoreCase = true)
                        }
                        if (!duplicate) {
                            dao.insertMemory(
                                MemoryFactEntity(
                                    category = candidate.category,
                                    content = candidate.content,
                                    isAutoExtracted = true,
                                )
                            )
                        }
                    }
                }

                val historySnapshot = dao.getMessagesSnapshot(convoId)
                val memoriesSnapshot = if (config.longTermMemoryEnabled) {
                    dao.getMemoriesSnapshot()
                } else {
                    emptyList()
                }

                val reply = aiRepository.generateReply(
                    userMessage = text,
                    history = historySnapshot,
                    memories = memoriesSnapshot,
                    personality = config,
                )

                val replyTime = System.currentTimeMillis()
                val replyId = dao.insertMessage(
                    ChatMessageEntity(
                        conversationId = convoId,
                        isFromUser = false,
                        content = reply.text,
                        timestamp = replyTime,
                        isVoiceInput = false,
                        isPreviewReply = reply.isPreviewSample,
                    )
                )

                dao.updateConversationSummary(
                    id = convoId,
                    title = updatedTitle,
                    updatedAt = replyTime,
                    preview = reply.text.removePrefix("[Sample Preview] ").take(80),
                )

                if (speakReplyOverride || config.autoSpeakReplies || isVoiceStudioOpen.value) {
                    voiceEngine.speak(
                        text = reply.text,
                        messageId = replyId,
                        pitch = config.voicePitch,
                        speed = config.voiceSpeed,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                statusNotice.value = e.localizedMessage ?: "Unable to compose response."
            } finally {
                isComposingReply.value = false
            }
        }
    }

    fun startNewConversation() {
        viewModelScope.launch {
            voiceEngine.stopSpeaking()
            val id = dao.insertConversation(
                ConversationEntity(
                    title = "New Conversation",
                    lastMessagePreview = "Quietly waiting for your thoughts…",
                )
            )
            prefs.setActiveConversationId(id)
        }
    }

    fun selectConversation(conversationId: Long) {
        viewModelScope.launch {
            voiceEngine.stopSpeaking()
            prefs.setActiveConversationId(conversationId)
        }
    }

    fun deleteConversation(conversationId: Long) {
        viewModelScope.launch {
            dao.deleteConversation(conversationId)
            val remaining = uiState.value.conversations.filterNot { it.id == conversationId }
            val nextId = remaining.firstOrNull()?.id ?: -1L
            prefs.setActiveConversationId(nextId)
        }
    }

    fun clearAllPrivateHistory() {
        viewModelScope.launch {
            voiceEngine.stopSpeaking()
            dao.deleteAllConversations()
            prefs.setActiveConversationId(-1L)
            statusNotice.value = "All private conversations cleared."
        }
    }

    fun addMemoryFact(category: String, content: String) {
        val clean = content.trim()
        if (clean.isBlank()) return
        viewModelScope.launch {
            dao.insertMemory(
                MemoryFactEntity(
                    category = category.ifBlank { "Personal" },
                    content = clean,
                    isAutoExtracted = false,
                )
            )
            statusNotice.value = "Saved to Qalb's long-term memory."
        }
    }

    fun deleteMemoryFact(id: Long) {
        viewModelScope.launch {
            dao.deleteMemory(id)
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            dao.deleteAllMemories()
            statusNotice.value = "Long-term memories cleared."
        }
    }

    fun toggleLongTermMemory(enabled: Boolean) {
        viewModelScope.launch {
            prefs.updateLongTermMemoryEnabled(enabled)
        }
    }

    fun updatePersonalitySliders(
        warmth: Float,
        wit: Float,
        romance: Float,
        hinglish: Float,
    ) {
        viewModelScope.launch {
            prefs.updatePersonalitySliders(warmth, wit, romance, hinglish)
        }
    }

    fun updateCustomDirective(directive: String) {
        viewModelScope.launch {
            prefs.updateCustomDirective(directive)
        }
    }

    fun updateVoiceSettings(pitch: Float, speed: Float, autoSpeak: Boolean) {
        viewModelScope.launch {
            prefs.updateVoiceSettings(pitch, speed, autoSpeak)
        }
    }

    fun testVoiceCalibration() {
        val config = uiState.value.personality
        val sample = if (config.hinglishBlend >= 0.45f) {
            "Suno, main yahin hoon. Aaram se baat karo — koi jaldi nahi hai."
        } else {
            "I am right here. Take your time and tell me what is on your mind."
        }
        voiceEngine.speak(
            text = sample,
            messageId = -999L,
            pitch = config.voicePitch,
            speed = config.voiceSpeed,
        )
    }

    fun toggleMessagePlayback(message: ChatMessageEntity) {
        val voice = uiState.value.voiceState
        if (voice.isSpeaking && voice.speakingMessageId == message.id) {
            voiceEngine.stopSpeaking()
        } else {
            val config = uiState.value.personality
            voiceEngine.speak(
                text = message.content,
                messageId = message.id,
                pitch = config.voicePitch,
                speed = config.voiceSpeed,
            )
        }
    }

    fun openVoiceStudio() {
        isVoiceStudioOpen.value = true
    }

    fun closeVoiceStudio() {
        voiceEngine.stopListening()
        voiceEngine.stopSpeaking()
        isVoiceStudioOpen.value = false
    }

    fun startDictationIntoComposer() {
        voiceEngine.startListening { transcript ->
            val current = composerDraft.value
            composerDraft.value = if (current.isBlank()) transcript else "$current $transcript"
        }
    }

    fun startVoiceStudioTurn() {
        voiceEngine.startListening { transcript ->
            sendMessage(rawText = transcript, isVoiceInput = true, speakReplyOverride = true)
        }
    }

    fun stopListening() {
        voiceEngine.stopListening()
    }

    fun stopSpeaking() {
        voiceEngine.stopSpeaking()
    }

    fun clearVoiceError() {
        voiceEngine.clearError()
    }

    fun saveReferenceAvatar(uri: Uri) {
        viewModelScope.launch {
            prefs.saveCustomAvatarFromUri(uri)
                .onSuccess {
                    statusNotice.value = "Updated Qalb's reference portrait."
                }
                .onFailure { err ->
                    statusNotice.value = err.localizedMessage ?: "Couldn't load selected photo."
                }
        }
    }

    fun restorePermanentAvatar() {
        viewModelScope.launch {
            prefs.restorePermanentAvatar()
            statusNotice.value = "Restored Qalb's permanent portrait."
        }
    }

    fun enablePinLock(pin: String) {
        if (pin.length != 4 || !pin.all { it.isDigit() }) {
            pinError.value = "Enter a 4-digit numeric PIN."
            return
        }
        viewModelScope.launch {
            prefs.enablePinLock(pin)
            pinError.value = null
            statusNotice.value = "Private Vault PIN enabled."
        }
    }

    fun disablePinLock() {
        viewModelScope.launch {
            prefs.disablePinLock()
            isVaultLocked.value = false
            pinError.value = null
            statusNotice.value = "Private Vault PIN removed."
        }
    }

    fun lockVaultNow() {
        if (uiState.value.personality.pinLockEnabled) {
            voiceEngine.stopSpeaking()
            voiceEngine.stopListening()
            isVaultLocked.value = true
        }
    }

    fun unlockVault(pin: String) {
        val storedHash = uiState.value.personality.pinHash
        if (prefs.verifyPin(pin, storedHash)) {
            pinError.value = null
            isVaultLocked.value = false
        } else {
            pinError.value = "Incorrect PIN. Try again."
        }
    }

    fun dismissStatusNotice() {
        statusNotice.value = null
    }

    override fun onCleared() {
        super.onCleared()
        voiceEngine.release()
    }

    class Factory(private val context: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val db = QalbDatabase.getInstance(context)
            val prefs = QalbPreferencesRepository(context)
            val aiRepo: AiRepository = PlaceholderQalbAiRepository()
            val voice = QalbVoiceEngine(context)
            return QalbViewModel(db.qalbDao(), prefs, aiRepo, voice) as T
        }
    }
}
