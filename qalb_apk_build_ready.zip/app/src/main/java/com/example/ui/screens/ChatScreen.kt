package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.local.ChatMessageEntity
import com.example.ui.QalbUiState
import com.example.ui.components.QalbAvatar
import com.example.ui.theme.BurnishedGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.LocalQalbColors
import com.example.ui.theme.MutedGoldWash
import com.example.ui.theme.VoidBlack
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(
    state: QalbUiState,
    onDraftChange: (String) -> Unit,
    onSendMessage: (String) -> Unit,
    onToggleMessageSpeak: (ChatMessageEntity) -> Unit,
    onStartDictation: () -> Unit,
    onStopListening: () -> Unit,
    onOpenVoiceStudio: () -> Unit,
    onOpenPersona: () -> Unit,
    onLockVault: () -> Unit,
    onClearVoiceError: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val qalbColors = LocalQalbColors.current
    val listState = rememberLazyListState()
    var pendingAudioAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var permissionDeniedNote by remember { mutableStateOf<String?>(null) }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) {
            permissionDeniedNote = null
            pendingAudioAction?.invoke()
        } else {
            permissionDeniedNote = "Microphone permission is needed for voice input."
        }
        pendingAudioAction = null
    }

    fun requestAudioAndRun(action: () -> Unit) {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO,
        ) == PackageManager.PERMISSION_GRANTED
        if (hasPermission) {
            permissionDeniedNote = null
            action()
        } else {
            pendingAudioAction = action
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(state.messages.size, state.isComposingReply) {
        val total = state.messages.size + if (state.isComposingReply) 1 else 0
        if (total > 0) {
            listState.animateScrollToItem(total - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(VoidBlack, MaterialTheme.colorScheme.background)
                )
            )
            .imePadding(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // Header bar
        Surface(
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    QalbAvatar(
                        customAvatarPath = state.personality.customAvatarPath,
                        size = 46.dp,
                        isPulsing = state.voiceState.isSpeaking || state.isComposingReply,
                        showOnlineDot = true,
                        onClick = onOpenPersona,
                        modifier = Modifier.testTag("header_qalb_avatar"),
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable(onClick = onOpenPersona),
                    ) {
                        Text(
                            text = "QALB",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        val subtitle = when {
                            state.voiceState.isListening -> "Listening to you…"
                            state.isComposingReply -> "Thinking calmly…"
                            state.voiceState.isSpeaking -> "Speaking aloud…"
                            else -> "Quietly here • ${state.memories.size} memories"
                        }
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }

                    if (state.personality.pinLockEnabled) {
                        IconButton(
                            onClick = onLockVault,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("lock_vault_button"),
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Lock private vault",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }

                    FilledIconButton(
                        onClick = { requestAudioAndRun(onOpenVoiceStudio) },
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = MutedGoldWash,
                            contentColor = ChampagneGold,
                        ),
                        modifier = Modifier
                            .size(48.dp)
                            .border(1.dp, qalbColors.goldBorder, CircleShape)
                            .testTag("voice_conversation_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = stringResource(R.string.cd_voice_call),
                            modifier = Modifier.size(22.dp),
                        )
                    }
                }

                // Subtle hairline divider
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(qalbColors.goldBorder.copy(alpha = 0.6f))
                )
            }
        }

        // Required short in-app AI notice when Firebase is disabled
        if (!state.isLiveGeminiEnabled) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                border = BorderStroke(1.dp, qalbColors.goldBorder),
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp),
                    )
                    Text(
                        text = stringResource(R.string.ai_preview_notice),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
            }
        }

        // Transient voice or permission error chip
        val activeError = permissionDeniedNote ?: state.voiceState.voiceError
        AnimatedVisibility(visible = activeError != null, enter = fadeIn(), exit = fadeOut()) {
            activeError?.let { err ->
                Surface(
                    onClick = {
                        permissionDeniedNote = null
                        onClearVoiceError()
                    },
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .widthIn(max = 680.dp),
                ) {
                    Text(
                        text = err,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    )
                }
            }
        }

        // Chat message feed or Empty State
        Box(
            modifier = Modifier
                .weight(1f)
                .widthIn(max = 680.dp)
                .fillMaxWidth(),
        ) {
            if (state.messages.isEmpty() && !state.isComposingReply) {
                EmptyQalbConversation(
                    customAvatarPath = state.personality.customAvatarPath,
                    onStarterSelected = onSendMessage,
                    onAvatarTap = onOpenPersona,
                )
            } else {
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(
                        items = state.messages,
                        key = { it.id },
                    ) { message ->
                        ChatBubbleItem(
                            message = message,
                            customAvatarPath = state.personality.customAvatarPath,
                            isSpeakingThis = state.voiceState.isSpeaking &&
                                state.voiceState.speakingMessageId == message.id,
                            onToggleSpeak = { onToggleMessageSpeak(message) },
                        )
                    }

                    if (state.isComposingReply) {
                        item(key = "typing_indicator") {
                            TypingBubble(customAvatarPath = state.personality.customAvatarPath)
                        }
                    }
                }
            }
        }

        // Live listening transcript preview strip
        AnimatedVisibility(visible = state.voiceState.isListening) {
            Surface(
                color = MutedGoldWash,
                border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = null,
                        tint = ChampagneGold,
                        modifier = Modifier.size(18.dp),
                    )
                    Text(
                        text = state.voiceState.partialTranscript.ifBlank {
                            stringResource(R.string.voice_hint)
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        // Bottom Composer Capsule
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(26.dp),
            border = BorderStroke(1.dp, qalbColors.goldBorder),
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(
                    onClick = {
                        if (state.voiceState.isListening) {
                            onStopListening()
                        } else {
                            requestAudioAndRun(onStartDictation)
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("mic_input_button"),
                ) {
                    Icon(
                        imageVector = if (state.voiceState.isListening) {
                            Icons.Default.Stop
                        } else {
                            Icons.Default.Mic
                        },
                        contentDescription = stringResource(R.string.cd_microphone),
                        tint = if (state.voiceState.isListening) {
                            MaterialTheme.colorScheme.tertiary
                        } else {
                            MaterialTheme.colorScheme.primary
                        },
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 4.dp, vertical = 10.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    if (state.composerDraft.isEmpty()) {
                        Text(
                            text = stringResource(R.string.message_hint),
                            style = MaterialTheme.typography.bodyLarge,
                            color = qalbColors.subtleText,
                        )
                    }
                    BasicTextField(
                        value = state.composerDraft,
                        onValueChange = onDraftChange,
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                        ),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        maxLines = 4,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Sentences,
                            imeAction = ImeAction.Send,
                        ),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (state.composerDraft.isNotBlank()) {
                                    onSendMessage(state.composerDraft)
                                }
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("chat_input_field"),
                    )
                }

                AnimatedContent(
                    targetState = state.composerDraft.isNotBlank(),
                    label = "composer_action_switch",
                ) { hasText ->
                    if (hasText) {
                        FilledIconButton(
                            onClick = { onSendMessage(state.composerDraft) },
                            enabled = !state.isComposingReply,
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary,
                            ),
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("send_message_button"),
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = stringResource(R.string.cd_send_message),
                                modifier = Modifier.size(20.dp),
                            )
                        }
                    } else {
                        FilledIconButton(
                            onClick = { requestAudioAndRun(onOpenVoiceStudio) },
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = MutedGoldWash,
                                contentColor = ChampagneGold,
                            ),
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("voice_studio_fab"),
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = stringResource(R.string.cd_voice_call),
                                modifier = Modifier.size(22.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun EmptyQalbConversation(
    customAvatarPath: String?,
    onStarterSelected: (String) -> Unit,
    onAvatarTap: () -> Unit,
) {
    val qalbColors = LocalQalbColors.current
    val starters = listOf(
        "Aaj din thoda heavy tha…",
        "Late night thoughts?",
        "Kuch witty sunao",
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        QalbAvatar(
            customAvatarPath = customAvatarPath,
            size = 112.dp,
            onClick = onAvatarTap,
            modifier = Modifier.testTag("empty_state_qalb_avatar"),
        )
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = "Shaam dhal rahi hai.",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Bina kisi filter ke baat karo — main poori tawajjoh se sun raha hoon.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(max = 320.dp),
        )
        Spacer(modifier = Modifier.height(24.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            starters.forEachIndexed { idx, prompt ->
                Surface(
                    onClick = { onStarterSelected(prompt) },
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = BorderStroke(1.dp, qalbColors.goldBorder),
                    modifier = Modifier.testTag("starter_chip_$idx"),
                ) {
                    Text(
                        text = prompt,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun ChatBubbleItem(
    message: ChatMessageEntity,
    customAvatarPath: String?,
    isSpeakingThis: Boolean,
    onToggleSpeak: () -> Unit,
) {
    val qalbColors = LocalQalbColors.current
    val timeFormatter = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    val timeLabel = remember(message.timestamp) { timeFormatter.format(Date(message.timestamp)) }

    if (message.isFromUser) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp, 4.dp, 20.dp, 20.dp),
                color = qalbColors.userBubble,
                border = BorderStroke(1.dp, BurnishedGold.copy(alpha = 0.45f)),
                modifier = Modifier.widthIn(max = 310.dp),
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Text(
                        text = message.content,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.align(Alignment.End),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        if (message.isVoiceInput) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Voice message",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(12.dp),
                            )
                        }
                        Text(
                            text = timeLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = qalbColors.subtleText,
                        )
                    }
                }
            }
        }
    } else {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.Top,
        ) {
            QalbAvatar(
                customAvatarPath = customAvatarPath,
                size = 32.dp,
                isPulsing = isSpeakingThis,
                modifier = Modifier.padding(top = 2.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
                shape = RoundedCornerShape(4.dp, 20.dp, 20.dp, 20.dp),
                color = qalbColors.qalbBubble,
                border = BorderStroke(1.dp, qalbColors.goldBorder),
                modifier = Modifier.widthIn(max = 310.dp),
            ) {
                Column(modifier = Modifier.padding(start = 14.dp, end = 10.dp, top = 10.dp, bottom = 6.dp)) {
                    val cleanDisplay = message.content.removePrefix("[Sample Preview]").trim()
                    Text(
                        text = cleanDisplay,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Text(
                                text = timeLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = qalbColors.subtleText,
                            )
                            if (message.isPreviewReply) {
                                Text(
                                    text = "• Sample Preview",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                )
                            }
                        }

                        IconButton(
                            onClick = onToggleSpeak,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("speak_message_${message.id}"),
                        ) {
                            Icon(
                                imageVector = if (isSpeakingThis) {
                                    Icons.Default.Stop
                                } else {
                                    Icons.Default.VolumeUp
                                },
                                contentDescription = if (isSpeakingThis) {
                                    stringResource(R.string.cd_stop_voice)
                                } else {
                                    stringResource(R.string.cd_play_voice)
                                },
                                tint = if (isSpeakingThis) {
                                    MaterialTheme.colorScheme.tertiary
                                } else {
                                    MaterialTheme.colorScheme.primary
                                },
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TypingBubble(customAvatarPath: String?) {
    val qalbColors = LocalQalbColors.current
    val transition = rememberInfiniteTransition(label = "typing_dots")
    val alpha1 by transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(550), RepeatMode.Reverse),
        label = "dot1",
    )
    val alpha2 by transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(550, delayMillis = 180), RepeatMode.Reverse),
        label = "dot2",
    )
    val alpha3 by transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(550, delayMillis = 360), RepeatMode.Reverse),
        label = "dot3",
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        QalbAvatar(customAvatarPath = customAvatarPath, size = 32.dp, isPulsing = true)
        Spacer(modifier = Modifier.width(8.dp))
        Surface(
            shape = RoundedCornerShape(4.dp, 20.dp, 20.dp, 20.dp),
            color = qalbColors.qalbBubble,
            border = BorderStroke(1.dp, qalbColors.goldBorder),
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                listOf(alpha1, alpha2, alpha3).forEach { dotAlpha ->
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .alpha(dotAlpha)
                            .clip(CircleShape)
                            .background(ChampagneGold)
                    )
                }
            }
        }
    }
}
