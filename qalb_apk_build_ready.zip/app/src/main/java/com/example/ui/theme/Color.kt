package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Champagne Gold Luxury Palette
val VoidBlack = Color(0xFF060608)
val ObsidianSurface = Color(0xFF0E0E12)
val VelvetCard = Color(0xFF15151B)
val ElevatedCharcoal = Color(0xFF1D1D25)
val UserBubbleDark = Color(0xFF1E1A12)

val ChampagneGold = Color(0xFFD4AF37)
val WarmGoldHighlight = Color(0xFFF2D98D)
val BurnishedGold = Color(0xFF9E7E24)
val SubtleGoldBorder = Color(0xFF332B1A)
val MutedGoldWash = Color(0xFF231D12)

val WarmIvory = Color(0xFFEDE8DF)
val StoneMuted = Color(0xFF9E9689)
val AshSubtle = Color(0xFF6B655B)

val SoftRoseGoldError = Color(0xFFE07A7A)
val DeepRubyContainer = Color(0xFF33181A)
val EmeraldPresence = Color(0xFF63C795)
