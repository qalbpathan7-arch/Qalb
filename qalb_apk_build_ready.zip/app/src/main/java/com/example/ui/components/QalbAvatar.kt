package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.theme.BurnishedGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.LocalQalbColors
import com.example.ui.theme.WarmGoldHighlight
import java.io.File

@Composable
fun QalbAvatar(
    customAvatarPath: String?,
    size: Dp,
    modifier: Modifier = Modifier,
    isPulsing: Boolean = false,
    externalPulseScale: Float = 1f,
    showOnlineDot: Boolean = false,
    onClick: (() -> Unit)? = null,
) {
    val qalbColors = LocalQalbColors.current
    val infiniteTransition = rememberInfiniteTransition(label = "avatar_pulse")
    val animatedScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isPulsing) 1.07f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulse_scale",
    )

    val goldRingBrush = Brush.linearGradient(
        colors = listOf(ChampagneGold, BurnishedGold, WarmGoldHighlight)
    )

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center,
    ) {
        if (isPulsing || externalPulseScale > 1.01f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .scale(if (externalPulseScale > 1.01f) externalPulseScale else animatedScale)
                    .clip(CircleShape)
                    .background(ChampagneGold.copy(alpha = 0.16f))
            )
        }

        val clickableModifier = if (onClick != null) {
            Modifier.clickable(role = Role.Button, onClick = onClick)
        } else {
            Modifier
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(2.dp)
                .clip(CircleShape)
                .border(width = 1.5.dp, brush = goldRingBrush, shape = CircleShape)
                .padding(2.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface)
                .then(clickableModifier),
        ) {
            val customFile = customAvatarPath?.let { File(it) }?.takeIf { it.exists() }
            if (customFile != null) {
                AsyncImage(
                    model = customFile,
                    contentDescription = stringResource(R.string.cd_qalb_avatar),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Image(
                    painter = painterResource(id = R.drawable.img_qalb_avatar),
                    contentDescription = stringResource(R.string.cd_qalb_avatar),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }

        if (showOnlineDot) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(2.dp)
                    .size((size.value * 0.24f).coerceIn(9f, 14f).dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(2.dp)
                    .clip(CircleShape)
                    .background(qalbColors.onlinePresence)
            )
        }
    }
}
