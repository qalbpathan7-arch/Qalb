package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Face
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.QalbViewModel
import com.example.ui.components.VoiceStudioSheet
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HistoryMemoryScreen
import com.example.ui.screens.PersonalityAvatarScreen
import com.example.ui.screens.VaultLockScreen
import com.example.ui.theme.MutedGoldWash
import com.example.ui.theme.QalbTheme

const val ROUTE_CHAT = "chat"
const val ROUTE_VAULT = "vault"
const val ROUTE_PERSONA = "persona"

private data class QalbDestination(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String,
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )

        setContent {
            QalbTheme {
                QalbAppRoot()
            }
        }
    }
}

@Composable
private fun QalbAppRoot() {
    val context = LocalContext.current
    val viewModel: QalbViewModel = viewModel(factory = QalbViewModel.Factory(context))
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    if (state.isVaultLocked) {
        VaultLockScreen(
            customAvatarPath = state.personality.customAvatarPath,
            pinError = state.pinError,
            onPinSubmitted = viewModel::unlockVault,
        )
        return
    }

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_CHAT
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.statusNotice) {
        state.statusNotice?.let { message ->
            snackbarHostState.showSnackbar(message)
            viewModel.dismissStatusNotice()
        }
    }

    val destinations = remember {
        listOf(
            QalbDestination(
                route = ROUTE_CHAT,
                labelRes = R.string.nav_chat,
                selectedIcon = Icons.Filled.ChatBubble,
                unselectedIcon = Icons.Outlined.ChatBubbleOutline,
                testTag = "nav_chat",
            ),
            QalbDestination(
                route = ROUTE_VAULT,
                labelRes = R.string.nav_vault,
                selectedIcon = Icons.Filled.Lock,
                unselectedIcon = Icons.Outlined.Lock,
                testTag = "nav_vault",
            ),
            QalbDestination(
                route = ROUTE_PERSONA,
                labelRes = R.string.nav_persona,
                selectedIcon = Icons.Filled.Face,
                unselectedIcon = Icons.Outlined.Face,
                testTag = "nav_persona",
            ),
        )
    }

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavigationRail = maxWidth >= 600.dp

            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (!useNavigationRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 4.dp,
                        ) {
                            destinations.forEach { dest ->
                                val selected = currentRoute == dest.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateTo(dest.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = stringResource(dest.labelRes),
                                        )
                                    },
                                    label = { Text(stringResource(dest.labelRes)) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MutedGoldWash,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    ),
                                    modifier = Modifier.testTag(dest.testTag),
                                )
                            }
                        }
                    }
                },
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .padding(innerPadding),
                ) {
                    if (useNavigationRail) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surface,
                        ) {
                            destinations.forEach { dest ->
                                val selected = currentRoute == dest.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateTo(dest.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = stringResource(dest.labelRes),
                                        )
                                    },
                                    label = { Text(stringResource(dest.labelRes)) },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.primary,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MutedGoldWash,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    ),
                                    modifier = Modifier.testTag(dest.testTag),
                                )
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_CHAT,
                        modifier = Modifier.weight(1f),
                    ) {
                        composable(ROUTE_CHAT) {
                            ChatScreen(
                                state = state,
                                onDraftChange = viewModel::updateComposerDraft,
                                onSendMessage = { text -> viewModel.sendMessage(text) },
                                onToggleMessageSpeak = viewModel::toggleMessagePlayback,
                                onStartDictation = viewModel::startDictationIntoComposer,
                                onStopListening = viewModel::stopListening,
                                onOpenVoiceStudio = viewModel::openVoiceStudio,
                                onOpenPersona = { navigateTo(ROUTE_PERSONA) },
                                onLockVault = viewModel::lockVaultNow,
                                onClearVoiceError = viewModel::clearVoiceError,
                            )
                        }

                        composable(ROUTE_VAULT) {
                            HistoryMemoryScreen(
                                state = state,
                                onNewConversation = {
                                    viewModel.startNewConversation()
                                    navigateTo(ROUTE_CHAT)
                                },
                                onSelectConversation = { id ->
                                    viewModel.selectConversation(id)
                                    navigateTo(ROUTE_CHAT)
                                },
                                onDeleteConversation = viewModel::deleteConversation,
                                onClearAllHistory = viewModel::clearAllPrivateHistory,
                                onToggleLongTermMemory = viewModel::toggleLongTermMemory,
                                onAddMemory = viewModel::addMemoryFact,
                                onDeleteMemory = viewModel::deleteMemoryFact,
                                onClearAllMemories = viewModel::clearAllMemories,
                                onEnablePin = viewModel::enablePinLock,
                                onDisablePin = viewModel::disablePinLock,
                            )
                        }

                        composable(ROUTE_PERSONA) {
                            PersonalityAvatarScreen(
                                state = state,
                                onUploadReferenceImage = viewModel::saveReferenceAvatar,
                                onRestorePermanentAvatar = viewModel::restorePermanentAvatar,
                                onUpdateSliders = viewModel::updatePersonalitySliders,
                                onUpdateCustomDirective = viewModel::updateCustomDirective,
                                onUpdateVoiceSettings = viewModel::updateVoiceSettings,
                                onTestVoice = viewModel::testVoiceCalibration,
                            )
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = state.isVoiceStudioOpen,
            enter = fadeIn() + slideInVertically { it / 6 },
            exit = fadeOut() + slideOutVertically { it / 6 },
        ) {
            BackHandler(enabled = state.isVoiceStudioOpen) {
                viewModel.closeVoiceStudio()
            }
            VoiceStudioSheet(
                customAvatarPath = state.personality.customAvatarPath,
                voiceState = state.voiceState,
                isComposingReply = state.isComposingReply,
                latestQalbMessage = state.messages.lastOrNull { !it.isFromUser },
                isLiveGeminiEnabled = state.isLiveGeminiEnabled,
                onStartListening = viewModel::startVoiceStudioTurn,
                onStopListening = viewModel::stopListening,
                onStopSpeaking = viewModel::stopSpeaking,
                onDismiss = viewModel::closeVoiceStudio,
            )
        }
    }
}
