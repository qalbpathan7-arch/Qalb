package com.example.data.local

import android.content.Context
import android.net.Uri
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.File
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

private val Context.qalbDataStore: DataStore<Preferences> by preferencesDataStore(name = "qalb_prefs")

data class PersonalityConfig(
    val warmthLevel: Float = 0.85f,
    val witLevel: Float = 0.72f,
    val romanceSubtlety: Float = 0.65f,
    val hinglishBlend: Float = 0.78f,
    val voicePitch: Float = 0.80f,
    val voiceSpeed: Float = 0.93f,
    val autoSpeakReplies: Boolean = false,
    val longTermMemoryEnabled: Boolean = true,
    val customDirective: String = "",
    val customAvatarPath: String? = null,
    val pinLockEnabled: Boolean = false,
    val pinHash: String = "",
    val activeConversationId: Long = -1L,
)

class QalbPreferencesRepository(private val context: Context) {

    private object Keys {
        val WARMTH = floatPreferencesKey("warmth_level")
        val WIT = floatPreferencesKey("wit_level")
        val ROMANCE = floatPreferencesKey("romance_subtlety")
        val HINGLISH = floatPreferencesKey("hinglish_blend")
        val VOICE_PITCH = floatPreferencesKey("voice_pitch")
        val VOICE_SPEED = floatPreferencesKey("voice_speed")
        val AUTO_SPEAK = booleanPreferencesKey("auto_speak_replies")
        val MEMORY_ENABLED = booleanPreferencesKey("long_term_memory_enabled")
        val CUSTOM_DIRECTIVE = stringPreferencesKey("custom_directive")
        val CUSTOM_AVATAR_PATH = stringPreferencesKey("custom_avatar_path")
        val PIN_LOCK_ENABLED = booleanPreferencesKey("pin_lock_enabled")
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val ACTIVE_CONVERSATION_ID = longPreferencesKey("active_conversation_id")
    }

    val configFlow: Flow<PersonalityConfig> = context.qalbDataStore.data.map { prefs ->
        PersonalityConfig(
            warmthLevel = prefs[Keys.WARMTH] ?: 0.85f,
            witLevel = prefs[Keys.WIT] ?: 0.72f,
            romanceSubtlety = prefs[Keys.ROMANCE] ?: 0.65f,
            hinglishBlend = prefs[Keys.HINGLISH] ?: 0.78f,
            voicePitch = prefs[Keys.VOICE_PITCH] ?: 0.80f,
            voiceSpeed = prefs[Keys.VOICE_SPEED] ?: 0.93f,
            autoSpeakReplies = prefs[Keys.AUTO_SPEAK] ?: false,
            longTermMemoryEnabled = prefs[Keys.MEMORY_ENABLED] ?: true,
            customDirective = prefs[Keys.CUSTOM_DIRECTIVE] ?: "",
            customAvatarPath = prefs[Keys.CUSTOM_AVATAR_PATH]?.takeIf { path ->
                path.isNotBlank() && File(path).exists()
            },
            pinLockEnabled = prefs[Keys.PIN_LOCK_ENABLED] ?: false,
            pinHash = prefs[Keys.PIN_HASH] ?: "",
            activeConversationId = prefs[Keys.ACTIVE_CONVERSATION_ID] ?: -1L,
        )
    }

    suspend fun updatePersonalitySliders(
        warmth: Float,
        wit: Float,
        romance: Float,
        hinglish: Float,
    ) {
        context.qalbDataStore.edit { prefs ->
            prefs[Keys.WARMTH] = warmth.coerceIn(0f, 1f)
            prefs[Keys.WIT] = wit.coerceIn(0f, 1f)
            prefs[Keys.ROMANCE] = romance.coerceIn(0f, 1f)
            prefs[Keys.HINGLISH] = hinglish.coerceIn(0f, 1f)
        }
    }

    suspend fun updateVoiceSettings(
        pitch: Float,
        speed: Float,
        autoSpeak: Boolean,
    ) {
        context.qalbDataStore.edit { prefs ->
            prefs[Keys.VOICE_PITCH] = pitch.coerceIn(0.65f, 1.1f)
            prefs[Keys.VOICE_SPEED] = speed.coerceIn(0.75f, 1.25f)
            prefs[Keys.AUTO_SPEAK] = autoSpeak
        }
    }

    suspend fun updateLongTermMemoryEnabled(enabled: Boolean) {
        context.qalbDataStore.edit { prefs ->
            prefs[Keys.MEMORY_ENABLED] = enabled
        }
    }

    suspend fun updateCustomDirective(directive: String) {
        context.qalbDataStore.edit { prefs ->
            prefs[Keys.CUSTOM_DIRECTIVE] = directive.take(400)
        }
    }

    suspend fun setActiveConversationId(id: Long) {
        context.qalbDataStore.edit { prefs ->
            prefs[Keys.ACTIVE_CONVERSATION_ID] = id
        }
    }

    suspend fun saveCustomAvatarFromUri(uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val targetFile = File(context.filesDir, "qalb_custom_avatar_${System.currentTimeMillis()}.jpg")
            // Remove older custom avatar files to keep internal storage clean
            context.filesDir.listFiles { file ->
                file.name.startsWith("qalb_custom_avatar_") && file.name.endsWith(".jpg")
            }?.forEach { oldFile -> oldFile.delete() }

            context.contentResolver.openInputStream(uri)?.use { input ->
                targetFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: error("Unable to read selected image")

            context.qalbDataStore.edit { prefs ->
                prefs[Keys.CUSTOM_AVATAR_PATH] = targetFile.absolutePath
            }
            targetFile.absolutePath
        }
    }

    suspend fun restorePermanentAvatar() = withContext(Dispatchers.IO) {
        context.filesDir.listFiles { file ->
            file.name.startsWith("qalb_custom_avatar_") && file.name.endsWith(".jpg")
        }?.forEach { it.delete() }

        context.qalbDataStore.edit { prefs ->
            prefs.remove(Keys.CUSTOM_AVATAR_PATH)
        }
    }

    suspend fun enablePinLock(pin: String) {
        val hash = sha256(pin)
        context.qalbDataStore.edit { prefs ->
            prefs[Keys.PIN_HASH] = hash
            prefs[Keys.PIN_LOCK_ENABLED] = true
        }
    }

    suspend fun disablePinLock() {
        context.qalbDataStore.edit { prefs ->
            prefs[Keys.PIN_LOCK_ENABLED] = false
            prefs[Keys.PIN_HASH] = ""
        }
    }

    fun verifyPin(pin: String, storedHash: String): Boolean {
        return storedHash.isNotBlank() && sha256(pin) == storedHash
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
