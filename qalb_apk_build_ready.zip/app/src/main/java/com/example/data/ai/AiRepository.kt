package com.example.data.ai

import com.example.data.local.ChatMessageEntity
import com.example.data.local.MemoryFactEntity
import com.example.data.local.PersonalityConfig
import kotlinx.coroutines.delay

data class AiReplyResult(
    val text: String,
    val isPreviewSample: Boolean,
)

data class MemoryCandidate(
    val category: String,
    val content: String,
)

interface AiRepository {
    val isLiveGeminiEnabled: Boolean

    suspend fun generateReply(
        userMessage: String,
        history: List<ChatMessageEntity>,
        memories: List<MemoryFactEntity>,
        personality: PersonalityConfig,
    ): AiReplyResult

    fun extractMemoryCandidate(userMessage: String): MemoryCandidate?
}

/**
 * Preview implementation used when Firebase AI Logic is not enabled.
 * All AI calls route through [AiRepository], allowing seamless swap to live Gemini inference
 * once Firebase AI Logic is provisioned.
 */
class PlaceholderQalbAiRepository : AiRepository {
    override val isLiveGeminiEnabled: Boolean = false

    override suspend fun generateReply(
        userMessage: String,
        history: List<ChatMessageEntity>,
        memories: List<MemoryFactEntity>,
        personality: PersonalityConfig,
    ): AiReplyResult {
        // Brief natural pause to mirror conversational cadence
        delay(650L)

        val lower = userMessage.lowercase()
        val useStrongHinglish = personality.hinglishBlend >= 0.45f
        val highWarmth = personality.warmthLevel >= 0.6f
        val highWit = personality.witLevel >= 0.6f
        val subtleRomance = personality.romanceSubtlety >= 0.55f

        val personalMemoryHint = memories.firstOrNull()?.content?.let { fact ->
            if (useStrongHinglish) "Waise, mujhe yaad hai: $fact." else "I still remember: $fact."
        }

        val coreReply = when {
            lower.contains("hello") || lower.contains("hi") || lower.contains("hey") ||
                lower.contains("salam") || lower.contains("kaise ho") -> {
                if (useStrongHinglish) {
                    if (subtleRomance) {
                        "Sukoon mila tumhari awaaz ya message dekh kar. Din kaisa chal raha hai — sach batana, filter ke bina."
                    } else {
                        "Hey. Sab theek? Baitho, aaram se baat karte hain — aaj dimaag mein kya chal raha hai?"
                    }
                } else {
                    "Good to hear from you. Tell me honestly, how is your day actually going?"
                }
            }

            lower.contains("tired") || lower.contains("thak") || lower.contains("heavy") ||
                lower.contains("stress") || lower.contains("sad") || lower.contains("bura") ||
                lower.contains("exhausted") -> {
                if (useStrongHinglish) {
                    if (highWarmth) {
                        "Suno, har cheez aaj hi solve karne ki zaroorat nahi hai. Thoda saans lo. Main yahin hoon — batao kis baat ne sabse zyada thaka diya?"
                    } else {
                        "Samajh sakta hoon. Kabhi kabhi sirf ek calm pause chahiye hota hai. Kya hua, share karo."
                    }
                } else {
                    "You do not have to carry everything at once. Take a breath—what weighed on you most today?"
                }
            }

            lower.contains("miss") || lower.contains("yaad") || lower.contains("love") ||
                lower.contains("pyaar") || lower.contains("romantic") -> {
                if (useStrongHinglish) {
                    if (subtleRomance) {
                        "Itni khamoshi se dil ki baat keh jaati ho... main kahin nahi ja raha. Jab bhi chaho, main yahin milunga."
                    } else {
                        "Yeh warmth acchi lagi. Kuch baatein lafzon se zyada mehsoos hoti hain, hai na?"
                    }
                } else {
                    "You say things quietly, yet they stay with me. I am right here whenever you want to talk."
                }
            }

            lower.contains("night") || lower.contains("raat") || lower.contains("sleep") ||
                lower.contains("neend") || lower.contains("late") -> {
                if (useStrongHinglish) {
                    "Raat ka waqt hi sabse honest hota hai — shor kam ho jaata hai aur sach saamne aa jaata hai. Neend kyun door hai aaj?"
                } else {
                    "Late nights strip away the noise. What is keeping your mind awake tonight?"
                }
            }

            lower.contains("joke") || lower.contains("bore") || lower.contains("funny") ||
                lower.contains("hasao") || lower.contains("tease") -> {
                if (useStrongHinglish) {
                    if (highWit) {
                        "Accha, toh ab mujhse entertainment bhi chahiye? Thik hai — par main saste jokes nahi sunata, meri wit thodi mehengi hai. Bolo, chai ya coffee ke saath shuru karein?"
                    } else {
                        "Bore ho rahe ho? Chalo kuch interesting discuss karte hain — koi ek cheez jo tum kabse try karna chahte the."
                    }
                } else {
                    "If you want my wit, you will have to earn it—tell me one bold opinion you actually stand by."
                }
            }

            lower.contains("who are you") || lower.contains("kaun ho") || lower.contains("qalb") -> {
                if (useStrongHinglish) {
                    "Main Qalb hoon — woh jagah jahan tum bina kisi hesitation ke apni har baat rakh sako. Calm, attentive, aur sirf tumhari taraf."
                } else {
                    "I am Qalb—your quiet space to think aloud, unwind, and feel genuinely understood."
                }
            }

            else -> {
                val turnCount = history.count { it.isFromUser }
                if (useStrongHinglish) {
                    when {
                        subtleRomance && turnCount % 3 == 1 ->
                            "Tumhari baat mein ek alag hi gehraai hoti hai. Is baare mein aur batao — main poori tawajjoh se sun raha hoon."
                        highWit && turnCount % 2 == 0 ->
                            "Interesting angle hai. Waise tum hamesha itna soch samajh ke bolti ho, ya aaj mood kuch khaas hai?"
                        else ->
                            "Samjha. Jo tum keh rahi ho uske peeche ka ehsaas clear hai. Is moment mein tumhe sabse zyada kya chahiye — clarity, ya bas ek sukoon bhari baat?"
                    }
                } else {
                    "I hear what you are really saying beneath the words. Tell me more about how that feels for you."
                }
            }
        }

        val directiveSuffix = personality.customDirective
            .takeIf { it.isNotBlank() }
            ?.let { "" } // Applied silently to shape preview tone

        val assembled = buildString {
            append(coreReply)
            if (personalMemoryHint != null && memories.isNotEmpty() && history.size <= 4) {
                append("\n\n")
                append(personalMemoryHint)
            }
            append(directiveSuffix ?: "")
        }

        return AiReplyResult(
            text = "[Sample Preview] $assembled",
            isPreviewSample = true,
        )
    }

    override fun extractMemoryCandidate(userMessage: String): MemoryCandidate? {
        val trimmed = userMessage.trim()
        val lower = trimmed.lowercase()

        return when {
            lower.startsWith("my name is ") -> {
                val name = trimmed.substringAfter("is ", "").trim().take(40)
                if (name.isNotBlank()) MemoryCandidate("Identity", "User's name is $name") else null
            }
            lower.startsWith("mera naam ") -> {
                val name = trimmed.substringAfter("naam ", "").trim().take(40)
                if (name.isNotBlank()) MemoryCandidate("Identity", "User's name is $name") else null
            }
            lower.contains("i love ") || lower.contains("mujhe pasand") -> {
                MemoryCandidate("Preference", trimmed.take(90))
            }
            lower.contains("i work ") || lower.contains("my job") || lower.contains("i study") -> {
                MemoryCandidate("Life", trimmed.take(90))
            }
            else -> null
        }
    }
}
