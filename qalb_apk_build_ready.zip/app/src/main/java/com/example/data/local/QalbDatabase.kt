package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ConversationEntity::class, ChatMessageEntity::class, MemoryFactEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class QalbDatabase : RoomDatabase() {
    abstract fun qalbDao(): QalbDao

    companion object {
        @Volatile
        private var instance: QalbDatabase? = null

        fun getInstance(context: Context): QalbDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    QalbDatabase::class.java,
                    "qalb_private_vault.db",
                ).build().also { instance = it }
            }
        }
    }
}
